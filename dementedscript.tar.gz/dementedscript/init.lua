local modpath = minetest.get_modpath(minetest.get_current_modname())

dofile(modpath .. "/entities.lua")

dofile(modpath .. "/items.lua")

dofile(modpath .. "/spawn.lua")